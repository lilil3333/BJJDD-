<?php 
/**
 * 后台公用函数库
 */

/**
 * 分页函数
 *
 * @param int $num	
 * @param int $perpage
 * @param int $curpage
 * @param string $mpurl
 * @param int $maxpages
 * @param int $page
 * @param bool $autogoto
 * @param bool $simple
 * @return string
 */
function multi($num, $perpage, $curpage, $mpurl, $maxpages = 0, $page = 10, $autogoto = TRUE, $simple = FALSE) {
	global $maxpage;
		$shownum = $showkbd = TRUE;
		$lang['prev'] = '上一页';
		$lang['next'] = '下一页';

	$multipage = '';
	$mpurl .= strpos($mpurl, '?') ? '&amp;' : '?';
	$realpages = 1;									
	if($num > $perpage) {
		$offset = 2;

		$realpages = @ceil($num / $perpage);
		$pages = $maxpages && $maxpages < $realpages ? $maxpages : $realpages;

		if($page > $pages) {
			$from = 1;
			$to = $pages;
		} else {
			$from = $curpage - $offset;
			$to = $from + $page - 1;
			if($from < 1) {
				$to = $curpage + 1 - $from;
				$from = 1;
				if($to - $from < $page) {
					$to = $page;
				}
			} elseif($to > $pages) {
				$from = $pages - $page + 1;
				$to = $pages;
			}
		}

		$multipage = ($curpage - $offset > 1 && $pages > $page ? '<a href="'.$mpurl.'page=1" class="first">首页</a> ' : '').
			($curpage > 1 && !$simple ? '<a href="'.$mpurl.'page='.($curpage - 1).'" class="prev">'.$lang['prev'].'</a> ' : '');
		for($i = $from; $i <= $to; $i++) {
			$multipage .= $i == $curpage ? '<strong><font style="color:#ff0000">'.$i.'</font></strong> ' :
				'<a href="'.$mpurl.'page='.$i.($i == $pages && $autogoto ? '#' : '').'">'.$i.'</a> ';
		}

		$multipage .= ($to < $pages ? '<a href="'.$mpurl.'page='.$pages.'" class="last">... '.$realpages.'</a> ': '').
			($curpage < $pages && !$simple ? '<a href="'.$mpurl.'page='.($curpage + 1).'" class="next">'.$lang['next'].'</a> ' : '').
			($showkbd && !$simple && $pages > $page ? '<kbd><input type="text" name="custompage" size="3" onkeydown="if(event.keyCode==13) {window.location=\''.$mpurl.'page=\'+this.value; return false;}" /></kbd>' : '');

		$multipage = $multipage ? '<div class="pages">'.($shownum && !$simple ? '共&nbsp;<font style="color:#ff0000">'.$num.'</font>&nbsp;条 ' : '').$multipage.'</div>' : '';
	}
	$maxpage = $realpages;
	return $multipage;
}

/**
 * 栏目分类下拉框 <option></option>
 *
 * @param int $pid
 * @param int $id
 * @param int $level
 */
function getCategorySelect($select_id=0,$id = 0,$level = 0){
	global $db;
	$category_arr = $db->getList ( "select * from cms_category where pid = " . $id . " order by seq" );
	for($lev = 0; $lev < $level * 2 - 1; $lev ++) {
		$level_nbsp .= "　";
	}
	if ($level++) $level_nbsp .= "┝";
	foreach ( $category_arr as $category ) {
		$id = $category ['id'];
		$name = $category ['name'];
		$selected = $select_id==$id?'selected':'';
		echo "<option value=\"".$id."\" ".$selected.">".$level_nbsp . " " . $name."</option>\n";
		getCategorySelect ($select_id, $id, $level );
	}
}

/***********************************
			图片上传函数
***********************************/
function uploadFile($filename){
    global $db;
    global $config;

    // 上传目录
    $attachment_dir = "attachment/".date('Ym')."/";
    !is_dir(ROOT_PATH.$attachment_dir) && mkdir(ROOT_PATH.$attachment_dir, 0755, true);

    // 黑名单后缀（危险脚本类）
    $DeniedExtensions = array('php3','php4','php5','jsp','asp','aspx','cgi','exe','sh','pl');

    // 获取文件扩展名
    $Extensions = strtolower(pathinfo($_FILES[$filename]['name'], PATHINFO_EXTENSION));

    // 检查扩展名是否在黑名单中
    if(in_array($Extensions, $DeniedExtensions)){
        exit("<script>alert('非法文件类型，禁止上传！');window.history.go(-1)</script>");
    }

    // MIME 类型检测（只允许常见图片）
    $AllowedMime = array('image/jpeg','image/png','image/gif','image/bmp');
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime_type = finfo_file($finfo, $_FILES[$filename]['tmp_name']);
    finfo_close($finfo);

    if(!in_array($mime_type, $AllowedMime)){
        exit("<script>alert('文件类型不合法，请上传图片！');window.history.go(-1)</script>");
    }

    // 文件头检测（防止伪造 Content-Type）
    $img_info = @getimagesize($_FILES[$filename]['tmp_name']);
    if($img_info === false){
        exit("<script>alert('文件内容不合法，请上传真实图片！');window.history.go(-1)</script>");
    }

    // 统一重命名文件
    $file_name = date('YmdHis').'_'.rand(10,99).'.'.$Extensions;
    $upload_file = $attachment_dir.$file_name;
    $upload_absolute_file = ROOT_PATH.$upload_file;

    // 执行上传
    if (move_uploaded_file($_FILES[$filename]['tmp_name'], $upload_absolute_file)) {
        $record = array(
            'filename'      => $file_name,
            'ffilename'     => $_FILES[$filename]['name'],
            'path'          => $upload_file,
            'ext'           => $Extensions,
            'size'          => $_FILES[$filename]['size'],
            'upload_date'   => date("Y-m-d H:i:s")
        );
        $id = $db->insert('cms_file', $record);
        return $upload_file;
    } else {
        exit("<script>alert('上传失败，请重试！');window.history.go(-1)</script>");
    }
}

?>