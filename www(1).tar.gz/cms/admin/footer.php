<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title></title>
<style type="text/css">
<!--
a:link {
	color: #000000;
}
a:visited {
	color: #000000;
}
a:hover {
	color: #000000;
}
a:active {
	color: #000000;
}
-->
</style></head>

<body style="margin:0px">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td height="8" background="admin/images/20070906_01.gif"></td>
  </tr>
  <tr>
    <td height="27" background="admin/images/20070906_05.jpg" align="center" style=" font-size:12px"><a href="http://www.test.com" target="_blank">AACMS&nbsp;&nbsp;V0.1.1</a> 官方网站:<a href="http://www.test.com" target="_blank">test.com</a></td>
  </tr>
</table>
</body>
</html>
