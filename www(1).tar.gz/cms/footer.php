<table width="100%" border="0" cellspacing="0" cellpadding="0" class=" bottomBg">
<tr>
    <td height="70" align="center" class="hui">
	  BJJDD文章管理系统 <a href="https://github.com/" class="hui12" target="_blank">GitHub.com</a>  比较简单的文章管理系统 <br />
      邮箱：GitHub@GitHub.com<br /></td>
 </tr>
</table>
</div>
</body>
</html>