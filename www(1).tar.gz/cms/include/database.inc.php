<?php
//���ݿ������ļ�
define ('DB_TYPE','mysql');
define ('DB_HOST','localhost');
define ('DB_USER','cms');
define ('DB_PWD','1109dLuEKSzZ');
define ('DB_NAME','cms');
define ('DB_CHARSET','utf8');
?>